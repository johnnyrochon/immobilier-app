
# RealEstate Manager - Build .exe for Windows (simple guide)

This project is a single-file Python Tkinter desktop app with SQLite database (`realestate.db`).

You asked for a ready-to-run `.exe`. I cannot produce the compiled `.exe` directly from this environment, but I provide **everything** needed so you (or someone with a Windows PC) can produce it in **two clicks** using Auto-py-to-exe, or with a single command using PyInstaller.

## Option A — Auto-py-to-exe (GUI, easiest for non-tech users)
1. On a Windows PC, download and install Python 3.10+ from python.org (choose the Windows installer, and check "Add Python to PATH").
2. Open a Command Prompt and run:

```
python -m pip install --upgrade pip
python -m pip install auto-py-to-exe
```
3. Run Auto-py-to-exe GUI:

```
auto-py-to-exe
```

4. In the GUI:
   - Script Location: select `realestate.py` from the unzipped folder.
   - Onefile: check **One file** (creates single `.exe`).
   - Console Window: **unchecked** if you want no console (set `--noconsole`). For this app, console is not required.
   - Icon (optional): choose an `.ico` if you have one.
   - Click **Convert .py to .exe**. When finished, the `.exe` will be in the `output` folder and you can copy it anywhere and double-click to run.

This is the simplest route and works well for non-technical users.

## Option B — PyInstaller (single command)
1. Install PyInstaller:

```
python -m pip install pyinstaller
```

2. From the project folder run (single command):

```
pyinstaller --onefile --noconsole realestate.py
```

3. The generated `realestate.exe` will appear in the `dist` folder.

Notes:
- If Windows Defender warns on the first run, choose "Run anyway" (this happens for newly created executables not yet signed).
- The SQLite database (`realestate.db`) will be created in the same folder as the `.exe` on first run. Move the `.exe` together with the `realestate.db` to keep data.

## Option C — Build on GitHub Actions (automatic cloud build)
I can also provide a GitHub Actions workflow so that when you push the project to GitHub, it builds a Windows `.exe` for you and exposes it as a downloadable artifact. This requires a free GitHub account and a push to the repo; I'll prepare the workflow if you want.

## Inno Setup (optional installer)
There's a `build_inno.iss` template in the ZIP. After producing the `.exe`, you can create a professional installer using Inno Setup on Windows.

---
If you want, I can also:
- prepare a GitHub Actions YAML so the .exe is built automatically when you upload the project; OR
- prepare a sample icon file and small branding; OR
- produce an installer script (Inno Setup) ready to build.
