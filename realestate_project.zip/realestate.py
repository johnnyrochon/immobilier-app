#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""RealEstate Manager - simple desktop app (Tkinter + SQLite)
Features:
- Add / Edit / Delete properties
- Add clients
- Record a sale linking property + client
- List properties, clients, sales
- Export lists to CSV
This is a compact single-file starting point intended to be converted to a Windows .exe using PyInstaller or Auto-py-to-exe.
"""


import tkinter as tk
from tkinter import ttk, messagebox, simpledialog, filedialog
import sqlite3, os, csv
from datetime import datetime

DB_PATH = os.path.join(os.path.dirname(__file__), 'realestate.db')

SCHEMA = '''
CREATE TABLE IF NOT EXISTS properties (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    address TEXT,
    price REAL,
    status TEXT DEFAULT 'available',
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS clients (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    phone TEXT,
    email TEXT,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS sales (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    property_id INTEGER NOT NULL,
    client_id INTEGER NOT NULL,
    price REAL,
    date TEXT NOT NULL,
    FOREIGN KEY(property_id) REFERENCES properties(id),
    FOREIGN KEY(client_id) REFERENCES clients(id)
);
'''

def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.executescript(SCHEMA)
    return conn

# --- Data operations ---
def add_property(title, address, price):
    with get_conn() as c:
        c.execute('INSERT INTO properties (title,address,price,created_at) VALUES (?,?,?,?)',
                  (title, address, price, datetime.utcnow().isoformat()))
        return c.lastrowid

def update_property(pid, title, address, price, status):
    with get_conn() as c:
        c.execute('UPDATE properties SET title=?,address=?,price=?,status=? WHERE id=?',
                  (title, address, price, status, pid))

def delete_property(pid):
    with get_conn() as c:
        c.execute('DELETE FROM properties WHERE id=?', (pid,))

def list_properties(all=False):
    with get_conn() as c:
        if all:
            return c.execute('SELECT id,title,address,price,status,created_at FROM properties ORDER BY id').fetchall()
        else:
            return c.execute('SELECT id,title,address,price,status,created_at FROM properties WHERE status<>'sold' ORDER BY id').fetchall()

def add_client(name, phone, email):
    with get_conn() as c:
        c.execute('INSERT INTO clients (name,phone,email,created_at) VALUES (?,?,?,?)',
                  (name, phone, email, datetime.utcnow().isoformat()))
        return c.lastrowid

def list_clients():
    with get_conn() as c:
        return c.execute('SELECT id,name,phone,email,created_at FROM clients ORDER BY id').fetchall()

def record_sale(property_id, client_id, price):
    with get_conn() as c:
        c.execute('INSERT INTO sales (property_id,client_id,price,date) VALUES (?,?,?,?)',
                  (property_id, client_id, price, datetime.utcnow().isoformat()))
        c.execute('UPDATE properties SET status=? WHERE id=?', ('sold', property_id))

def list_sales():
    with get_conn() as c:
        return c.execute('''SELECT s.id,p.title,c.name,s.price,s.date FROM sales s
                            JOIN properties p ON p.id = s.property_id
                            JOIN clients c ON c.id = s.client_id
                            ORDER BY s.id''').fetchall()

# --- UI ---
class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('Gestion Immobilière - RealEstate Manager')
        self.geometry('900x600')
        self.create_widgets()
        self.refresh_properties()

    def create_widgets(self):
        nb = ttk.Notebook(self)
        nb.pack(fill='both', expand=True, padx=8, pady=8)

        # Properties tab
        f1 = ttk.Frame(nb)
        nb.add(f1, text='Biens')

        frm_top = ttk.Frame(f1)
        frm_top.pack(fill='x', pady=6)
        ttk.Button(frm_top, text='Ajouter bien', command=self.dialog_add_property).pack(side='left')
        ttk.Button(frm_top, text='Modifier sélection', command=self.dialog_edit_property).pack(side='left')
        ttk.Button(frm_top, text='Supprimer', command=self.delete_selected_property).pack(side='left')
        ttk.Button(frm_top, text='Enregistrer CSV', command=lambda: self.export_csv('properties')).pack(side='right')
        ttk.Button(frm_top, text='Voir vendus', command=self.toggle_show_all).pack(side='right')

        cols = ('id','title','address','price','status','created_at')
        self.tree = ttk.Treeview(f1, columns=cols, show='headings', selectmode='browse')
        for c in cols:
            self.tree.heading(c, text=c)
            if c=='title': self.tree.column(c, width=220)
            elif c=='address': self.tree.column(c, width=220)
            else: self.tree.column(c, width=100)
        self.tree.pack(fill='both', expand=True)

        # Clients tab
        f2 = ttk.Frame(nb)
        nb.add(f2, text='Clients')
        top2 = ttk.Frame(f2)
        top2.pack(fill='x', pady=6)
        ttk.Button(top2, text='Ajouter client', command=self.dialog_add_client).pack(side='left')
        ttk.Button(top2, text='Exporter CSV', command=lambda: self.export_csv('clients')).pack(side='right')

        self.tree_clients = ttk.Treeview(f2, columns=('id','name','phone','email','created_at'), show='headings', selectmode='browse')
        for c in ('id','name','phone','email','created_at'):
            self.tree_clients.heading(c, text=c)
            self.tree_clients.column(c, width=140)
        self.tree_clients.pack(fill='both', expand=True)

        # Sales tab
        f3 = ttk.Frame(nb)
        nb.add(f3, text='Ventes')
        top3 = ttk.Frame(f3)
        top3.pack(fill='x', pady=6)
        ttk.Button(top3, text='Enregistrer vente', command=self.dialog_record_sale).pack(side='left')
        ttk.Button(top3, text='Exporter CSV', command=lambda: self.export_csv('sales')).pack(side='right')

        self.tree_sales = ttk.Treeview(f3, columns=('id','property','client','price','date'), show='headings', selectmode='browse')
        for c in ('id','property','client','price','date'):
            self.tree_sales.heading(c, text=c)
            self.tree_sales.column(c, width=140)
        self.tree_sales.pack(fill='both', expand=True)

        self.show_all = False

    def refresh_properties(self):
        for i in self.tree.get_children(): self.tree.delete(i)
        for row in list_properties(all=self.show_all):
            self.tree.insert('', 'end', values=row)
        # clients
        for i in self.tree_clients.get_children(): self.tree_clients.delete(i)
        for row in list_clients():
            self.tree_clients.insert('', 'end', values=row)
        # sales
        for i in self.tree_sales.get_children(): self.tree_sales.delete(i)
        for row in list_sales():
            self.tree_sales.insert('', 'end', values=row)

    def toggle_show_all(self):
        self.show_all = not self.show_all
        self.refresh_properties()

    def dialog_add_property(self):
        dlg = PropertyDialog(self, title='Nouvel bien')
        self.wait_window(dlg)
        if getattr(dlg,'result',None):
            title, address, price = dlg.result
            add_property(title, address, price or 0.0)
            self.refresh_properties()

    def dialog_edit_property(self):
        sel = self.tree.selection()
        if not sel: return messagebox.showinfo('Info','Sélectionner un bien')
        values = self.tree.item(sel[0])['values']
        pid = values[0]
        dlg = PropertyDialog(self, title='Modifier bien', values=values)
        self.wait_window(dlg)
        if getattr(dlg,'result',None):
            title, address, price, status = dlg.result
            update_property(pid, title, address, price or 0.0, status)
            self.refresh_properties()

    def delete_selected_property(self):
        sel = self.tree.selection()
        if not sel: return messagebox.showinfo('Info','Sélectionner un bien')
        values = self.tree.item(sel[0])['values']
        pid = values[0]
        if messagebox.askyesno('Confirmer','Supprimer ce bien ?'):
            delete_property(pid)
            self.refresh_properties()

    def dialog_add_client(self):
        name = simpledialog.askstring('Nouveau client','Nom complet:')
        if not name: return
        phone = simpledialog.askstring('Téléphone','Téléphone (optionnel):')
        email = simpledialog.askstring('Email','Email (optionnel):')
        add_client(name, phone or '', email or '')
        self.refresh_properties()

    def dialog_record_sale(self):
        # choose property and client by ID
        props = list_properties(all=False)
        if not props:
            return messagebox.showinfo('Info','Aucun bien disponible à vendre')
        # simple selection dialogs
        prop_map = {str(p[0]):p for p in props}
        prop_choice = simpledialog.askstring('Choisir bien','Entrez l\'ID du bien:\n' + '\n'.join([f"{p[0]}: {p[1]} ({p[4]})" for p in props]))
        if not prop_choice or prop_choice not in prop_map: return
        clients = list_clients()
        if not clients:
            return messagebox.showinfo('Info','Aucun client défini. Ajoutez un client d\'abord.')
        client_map = {str(c[0]):c for c in clients}
        client_choice = simpledialog.askstring('Choisir client','Entrez l\'ID du client:\n' + '\n'.join([f"{c[0]}: {c[1]}" for c in clients]))
        if not client_choice or client_choice not in client_map: return
        price_str = simpledialog.askstring('Prix de vente','Prix (laisser vide pour prix du bien):')
        price = None
        if price_str:
            try:
                price = float(price_str.replace(',','.'))
            except:
                messagebox.showerror('Erreur','Prix invalide'); return
        # finalize
        prop_id = int(prop_choice); client_id = int(client_choice)
        if price is None:
            # fetch property price
            for p in props:
                if p[0]==prop_id:
                    price = p[3] or 0.0; break
        record_sale(prop_id, client_id, price)
        messagebox.showinfo('OK','Vente enregistrée')
        self.refresh_properties()

    def export_csv(self, what):
        path = filedialog.asksaveasfilename(defaultextension='.csv', filetypes=[('CSV','*.csv')])
        if not path: return
        rows = []
        headers = []
        if what=='properties':
            rows = list_properties(all=True)
            headers = ['id','title','address','price','status','created_at']
        elif what=='clients':
            rows = list_clients()
            headers = ['id','name','phone','email','created_at']
        elif what=='sales':
            rows = list_sales()
            headers = ['id','property','client','price','date']
        try:
            with open(path,'w',newline='',encoding='utf-8') as f:
                w = csv.writer(f)
                w.writerow(headers)
                for r in rows: w.writerow(r)
            messagebox.showinfo('OK','Exporté: ' + path)
        except Exception as e:
            messagebox.showerror('Erreur','Impossible d\'écrire le fichier: ' + str(e))

class PropertyDialog(tk.Toplevel):
    def __init__(self, master, title='Property', values=None):
        super().__init__(master)
        self.title(title)
        self.result = None
        self.build(values)
        self.grab_set()
        self.transient(master)
        self.resizable(False,False)

    def build(self, values):
        ttk.Label(self, text='Titre:').grid(row=0,column=0,sticky='w', padx=6, pady=6)
        self.ent_title = ttk.Entry(self, width=60); self.ent_title.grid(row=0,column=1,padx=6,pady=6)
        ttk.Label(self, text='Adresse:').grid(row=1,column=0,sticky='w', padx=6, pady=6)
        self.ent_addr = ttk.Entry(self, width=60); self.ent_addr.grid(row=1,column=1,padx=6,pady=6)
        ttk.Label(self, text='Prix:').grid(row=2,column=0,sticky='w', padx=6, pady=6)
        self.ent_price = ttk.Entry(self, width=20); self.ent_price.grid(row=2,column=1,sticky='w', padx=6,pady=6)
        ttk.Label(self, text='Statut:').grid(row=3,column=0,sticky='w', padx=6, pady=6)
        self.cmb_status = ttk.Combobox(self, values=['available','reserved','sold'], state='readonly'); self.cmb_status.grid(row=3,column=1,sticky='w', padx=6,pady=6)
        btn = ttk.Button(self, text='Enregistrer', command=self.on_ok); btn.grid(row=4,column=0,columnspan=2,pady=10)
        if values:
            self.ent_title.insert(0, values[1])
            self.ent_addr.insert(0, values[2])
            self.ent_price.insert(0, str(values[3]))
            self.cmb_status.set(values[4])

    def on_ok(self):
        title = self.ent_title.get().strip()
        if not title: return messagebox.showerror('Erreur','Le titre est obligatoire')
        address = self.ent_addr.get().strip()
        price = 0.0
        try:
            price = float(self.ent_price.get().strip() or 0.0)
        except:
            return messagebox.showerror('Erreur','Prix invalide')
        status = self.cmb_status.get() or 'available'
        self.result = (title, address, price, status)
        self.destroy()

def ensure_db():
    # create DB file if missing
    get_conn().close()

def main():
    ensure_db()
    app = App()
    app.mainloop()

if __name__ == '__main__':
    main()
